import { Component } from "@angular/core";

@Component({
  selector:'app-student',
  template:'<h1>hello from student</h1>'
})

export class student{

}
