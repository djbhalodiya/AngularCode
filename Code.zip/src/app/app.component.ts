import { Component } from '@angular/core';
//include<'heade.h'>
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'test';

  counter=0;
  name="Dharmesh";
  surname="Bhalodiya";

  city=[];


  onclick(){
this.counter++;
  }


}
